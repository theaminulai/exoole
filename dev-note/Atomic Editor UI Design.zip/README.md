
  # Atomic Editor UI Design

  This is a code bundle for Atomic Editor UI Design. The original project is available at https://www.figma.com/design/jKMkPLVLwIglejcIreudjB/Atomic-Editor-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  