import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Search,
  Layers,
  Box,
  Type,
  Image,
  Zap,
  Code,
  Monitor,
  Tablet,
  Smartphone,
  Undo2,
  Redo2,
  Save,
  ChevronDown,
  ChevronRight,
  Plus,
  Trash2,
  Copy,
  GripVertical,
  Settings,
  Eye,
  Grid3x3,
  Layout,
  Columns,
  AlignLeft,
  AlignCenter,
  AlignRight,
  MousePointer,
  Link2,
  Command,
  Star,
  Play,
  Globe,
  Bold,
  Italic,
  ArrowRight,
  PanelLeft,
  PanelRight,
  Minus,
  SlidersHorizontal,
} from "lucide-react";

// ─── DATA ────────────────────────────────────────────────────────────────────

const BLOCK_CATEGORIES = [
  {
    id: "layout",
    name: "Layout",
    blocks: [
      { id: "section", label: "Section", icon: Layout },
      { id: "container", label: "Container", icon: Box },
      { id: "columns", label: "Columns", icon: Columns },
      { id: "grid", label: "Grid", icon: Grid3x3 },
    ],
  },
  {
    id: "content",
    name: "Content",
    blocks: [
      { id: "heading", label: "Heading", icon: Type },
      { id: "paragraph", label: "Paragraph", icon: AlignLeft },
      { id: "button", label: "Button", icon: MousePointer },
      { id: "divider", label: "Divider", icon: Minus },
    ],
  },
  {
    id: "interactive",
    name: "Interactive",
    blocks: [
      { id: "form", label: "Form", icon: Box },
      { id: "tabs", label: "Tabs", icon: Layout },
      {
        id: "accordion",
        label: "Accordion",
        icon: ChevronDown,
      },
      {
        id: "slider",
        label: "Slider",
        icon: SlidersHorizontal,
      },
    ],
  },
  {
    id: "media",
    name: "Media",
    blocks: [
      { id: "image", label: "Image", icon: Image },
      { id: "video", label: "Video", icon: Play },
      { id: "icon", label: "Icon", icon: Star },
      { id: "gallery", label: "Gallery", icon: Grid3x3 },
    ],
  },
  {
    id: "advanced",
    name: "Advanced",
    blocks: [
      { id: "html", label: "HTML", icon: Code },
      { id: "embed", label: "Embed", icon: Globe },
      { id: "code", label: "Code Block", icon: Zap },
      { id: "custom", label: "Custom", icon: Box },
    ],
  },
];

const CANVAS_BLOCKS = [
  { id: "hero", type: "hero", label: "Hero Section" },
  { id: "features", type: "features", label: "Features Grid" },
  {
    id: "testimonials",
    type: "testimonials",
    label: "Testimonials",
  },
  { id: "cta", type: "cta", label: "Call to Action" },
];

const COMMAND_ITEMS = [
  {
    id: "add",
    label: "Add New Section",
    shortcut: "N",
    icon: Plus,
  },
  {
    id: "toggle-left",
    label: "Toggle Left Panel",
    shortcut: "[",
    icon: PanelLeft,
  },
  {
    id: "toggle-right",
    label: "Toggle Right Panel",
    shortcut: "]",
    icon: PanelRight,
  },
  {
    id: "save",
    label: "Save Changes",
    shortcut: "⌘S",
    icon: Save,
  },
  { id: "undo", label: "Undo", shortcut: "⌘Z", icon: Undo2 },
  { id: "redo", label: "Redo", shortcut: "⌘⇧Z", icon: Redo2 },
  {
    id: "duplicate",
    label: "Duplicate Block",
    shortcut: "⌘D",
    icon: Copy,
  },
  {
    id: "delete",
    label: "Delete Block",
    shortcut: "⌫",
    icon: Trash2,
  },
  {
    id: "preview",
    label: "Preview Mode",
    shortcut: "⌘P",
    icon: Eye,
  },
  {
    id: "export",
    label: "Export Page",
    shortcut: "⌘E",
    icon: ArrowRight,
  },
];

// ─── SMALL UI HELPERS ─────────────────────────────────────────────────────────

function CLbl({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-[10px] font-semibold text-white/30 uppercase tracking-wider mb-1.5">
      {children}
    </div>
  );
}

function CGroup({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <CLbl>{label}</CLbl>
      {children}
    </div>
  );
}

function CInput({
  defaultValue,
  className = "",
}: {
  defaultValue?: string | number;
  className?: string;
}) {
  return (
    <input
      defaultValue={defaultValue}
      className={`w-full px-3 py-1.5 bg-[#12121a] rounded-xl border border-white/5 text-[12px] text-white/70 placeholder:text-white/20 outline-none focus:border-[#3858e9]/50 transition-colors ${className}`}
    />
  );
}

function SegBtn({
  options,
  active,
}: {
  options: string[];
  active: string;
}) {
  return (
    <div
      className="grid gap-1"
      style={{
        gridTemplateColumns: `repeat(${options.length}, 1fr)`,
      }}
    >
      {options.map((o) => (
        <button
          key={o}
          className={`py-1.5 rounded-xl text-[10px] font-medium transition-colors ${o === active ? "bg-[#3858e9]/15 text-[#3858e9] border border-[#3858e9]/25" : "bg-[#12121a] text-white/40 border border-white/5 hover:border-white/10 hover:text-white/60"}`}
        >
          {o}
        </button>
      ))}
    </div>
  );
}

// ─── INSPECTOR SECTIONS ───────────────────────────────────────────────────────

function LayoutControls() {
  return (
    <div className="space-y-3">
      <CGroup label="Display">
        <SegBtn
          options={["Block", "Flex", "Grid", "None"]}
          active="Block"
        />
      </CGroup>
      <CGroup label="Width">
        <div className="flex gap-1.5 items-center">
          <CInput defaultValue="100" className="text-center" />
          <div className="flex p-0.5 bg-[#12121a] rounded-xl border border-white/5 gap-0.5">
            {["%", "px", "vw"].map((u, i) => (
              <button
                key={u}
                className={`px-2 py-1 rounded-lg text-[10px] transition-colors ${i === 0 ? "bg-[#1a1a24] text-white" : "text-white/30 hover:text-white/60"}`}
              >
                {u}
              </button>
            ))}
          </div>
        </div>
      </CGroup>
      <CGroup label="Flex Direction">
        <SegBtn
          options={["Row", "Col", "Row-R", "Col-R"]}
          active="Row"
        />
      </CGroup>
      <CGroup label="Align Items">
        <SegBtn
          options={["Start", "Center", "End", "Stretch"]}
          active="Center"
        />
      </CGroup>
    </div>
  );
}

function SpacingControls() {
  return (
    <div className="space-y-3">
      <CLbl>Padding</CLbl>
      <div className="grid grid-cols-2 gap-1.5 mb-3">
        {[
          ["T", "48"],
          ["R", "0"],
          ["B", "48"],
          ["L", "0"],
        ].map(([s, v]) => (
          <div key={s} className="relative">
            <CInput
              defaultValue={v}
              className="pr-6 text-center"
            />
            <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[9px] text-white/20 font-bold">
              {s}
            </span>
          </div>
        ))}
      </div>
      <CLbl>Margin</CLbl>
      <div className="grid grid-cols-2 gap-1.5">
        {[
          ["T", "0"],
          ["R", "auto"],
          ["B", "0"],
          ["L", "auto"],
        ].map(([s, v]) => (
          <div key={s} className="relative">
            <CInput
              defaultValue={v}
              className="pr-6 text-center"
            />
            <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[9px] text-white/20 font-bold">
              {s}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function BackgroundControls() {
  return (
    <div className="space-y-3">
      <CGroup label="Type">
        <SegBtn
          options={["Solid", "Gradient", "Image", "Video"]}
          active="Solid"
        />
      </CGroup>
      <CGroup label="Color">
        <div className="flex items-center gap-2">
          <div
            className="size-8 rounded-xl border border-white/10 flex-shrink-0 cursor-pointer"
            style={{ background: "#ffffff" }}
          />
          <CInput
            defaultValue="#ffffff"
            className="font-mono"
          />
          <div className="flex-shrink-0 w-12">
            <CInput
              defaultValue="100"
              className="text-center"
            />
          </div>
        </div>
      </CGroup>
      <CGroup label="Overlay">
        <div className="flex items-center gap-2">
          <div
            className="size-8 rounded-xl border border-white/10 flex-shrink-0"
            style={{ background: "rgba(0,0,0,0)" }}
          />
          <CInput
            defaultValue="transparent"
            className="font-mono"
          />
        </div>
      </CGroup>
    </div>
  );
}

function TypographyControls() {
  return (
    <div className="space-y-3">
      <CGroup label="Font Family">
        <div className="relative">
          <select className="w-full px-3 py-1.5 bg-[#12121a] rounded-xl border border-white/5 text-[12px] text-white/70 outline-none focus:border-[#3858e9]/50 transition-colors appearance-none">
            <option>Inter</option>
            <option>Helvetica Neue</option>
            <option>Georgia</option>
            <option>Roboto</option>
          </select>
        </div>
      </CGroup>
      <div className="grid grid-cols-2 gap-2">
        <CGroup label="Size">
          <CInput defaultValue="16" className="text-center" />
        </CGroup>
        <CGroup label="Weight">
          <select
            defaultValue="600"
            className="w-full px-3 py-1.5 bg-[#12121a] rounded-xl border border-white/5 text-[12px] text-white/70 outline-none appearance-none"
          >
            <option value="400">400</option>
            <option value="500">500</option>
            <option value="600">600</option>
            <option value="700">700</option>
          </select>
        </CGroup>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <CGroup label="Line Height">
          <CInput defaultValue="1.5" className="text-center" />
        </CGroup>
        <CGroup label="Letter Spacing">
          <CInput defaultValue="0" className="text-center" />
        </CGroup>
      </div>
      <CGroup label="Align">
        <div className="flex gap-1">
          {[
            [AlignLeft, "Left"],
            [AlignCenter, "Center"],
            [AlignRight, "Right"],
          ].map(([Icon, label]: any) => (
            <button
              key={label}
              title={label}
              className={`flex-1 flex items-center justify-center py-1.5 rounded-xl border transition-colors ${label === "Left" ? "border-[#3858e9]/25 bg-[#3858e9]/10 text-[#3858e9]" : "border-white/5 bg-[#12121a] text-white/40 hover:text-white/70"}`}
            >
              <Icon size={12} />
            </button>
          ))}
        </div>
      </CGroup>
      <CGroup label="Style">
        <div className="flex gap-1">
          {[
            [Bold, "Bold"],
            [Italic, "Italic"],
            [Link2, "Link"],
          ].map(([Icon, label]: any) => (
            <button
              key={label}
              title={label}
              className="p-2 rounded-xl bg-[#12121a] border border-white/5 text-white/40 hover:text-white/70 hover:border-white/10 transition-colors"
            >
              <Icon size={12} />
            </button>
          ))}
        </div>
      </CGroup>
    </div>
  );
}

function EffectsControls() {
  return (
    <div className="space-y-3">
      <CGroup label="Opacity">
        <div className="flex items-center gap-2">
          <input
            type="range"
            min="0"
            max="100"
            defaultValue="100"
            className="flex-1 h-1 rounded-full appearance-none cursor-pointer bg-[#1a1a24] [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:size-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[#3858e9] [&::-webkit-slider-thumb]:cursor-pointer"
          />
          <div className="w-10">
            <CInput
              defaultValue="100"
              className="text-center text-[11px]"
            />
          </div>
        </div>
      </CGroup>
      <CGroup label="Box Shadow">
        <button className="w-full flex items-center justify-center gap-1.5 py-2 rounded-xl border border-dashed border-white/10 text-[11px] text-white/25 hover:border-white/20 hover:text-white/50 transition-colors">
          <Plus size={11} />
          Add Shadow
        </button>
      </CGroup>
      <CGroup label="CSS Filter">
        <SegBtn
          options={["None", "Blur", "Brightness", "Contrast"]}
          active="None"
        />
      </CGroup>
      <CGroup label="Mix Blend">
        <select className="w-full px-3 py-1.5 bg-[#12121a] rounded-xl border border-white/5 text-[12px] text-white/70 outline-none appearance-none">
          <option>Normal</option>
          <option>Multiply</option>
          <option>Screen</option>
          <option>Overlay</option>
        </select>
      </CGroup>
    </div>
  );
}

function BorderControls() {
  return (
    <div className="space-y-3">
      <CGroup label="Style">
        <SegBtn
          options={["None", "Solid", "Dashed", "Dotted"]}
          active="None"
        />
      </CGroup>
      <div className="grid grid-cols-2 gap-2">
        <CGroup label="Width">
          <CInput defaultValue="0" className="text-center" />
        </CGroup>
        <CGroup label="Radius">
          <CInput defaultValue="0" className="text-center" />
        </CGroup>
      </div>
      <CGroup label="Color">
        <div className="flex items-center gap-2">
          <div
            className="size-8 rounded-xl border border-white/10 flex-shrink-0"
            style={{ background: "#e2e8f0" }}
          />
          <CInput
            defaultValue="#e2e8f0"
            className="font-mono"
          />
        </div>
      </CGroup>
    </div>
  );
}

// ─── CANVAS BLOCK RENDERERS ───────────────────────────────────────────────────

function HeroBlock() {
  return (
    <div className="bg-white py-28 px-16 flex flex-col items-center text-center relative overflow-hidden">
      <div
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage:
            "radial-gradient(ellipse 80% 50% at 50% -20%, #3858e915, transparent)",
        }}
      />
      <div className="relative z-10 flex flex-col items-center">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-[#3858e9]/20 bg-[#3858e9]/5 mb-8">
          <Zap size={10} className="text-[#3858e9]" />
          <span className="text-[11px] text-[#3858e9] font-semibold tracking-wide uppercase">
            Next-gen WordPress Editor
          </span>
        </div>
        <h1 className="text-[56px] font-bold text-gray-950 leading-[1.05] tracking-[-0.03em] max-w-2xl mb-6">
          Build Faster,
          <br />
          <span style={{ color: "#3858e9" }}>
            Launch Smarter
          </span>
        </h1>
        <p className="text-[17px] text-gray-500 max-w-[520px] leading-[1.65] mb-10 font-normal">
          The professional block editor for developers and
          agencies. Create pixel-perfect WordPress sites with
          precision controls and clean code output.
        </p>
        <div className="flex items-center gap-3">
          <button className="px-7 py-3.5 bg-[#3858e9] text-white text-[14px] font-semibold rounded-2xl hover:bg-[#2a46d1] transition-all shadow-[0_4px_24px_rgba(56,88,233,0.35)]">
            Get Started Free
          </button>
          <button className="px-7 py-3.5 text-gray-700 text-[14px] font-medium rounded-2xl border border-gray-200 hover:border-gray-300 hover:bg-gray-50 transition-all flex items-center gap-2">
            Watch Demo <ArrowRight size={14} />
          </button>
        </div>
        <div className="flex items-center gap-6 mt-10 pt-8 border-t border-gray-100">
          {[
            ["14k+", "Active Sites"],
            ["99.9%", "Uptime SLA"],
            ["<50ms", "Build Time"],
          ].map(([v, l]) => (
            <div key={l} className="text-center">
              <div className="text-[18px] font-bold text-gray-900">
                {v}
              </div>
              <div className="text-[12px] text-gray-400 mt-0.5">
                {l}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function FeaturesBlock() {
  const features = [
    {
      icon: Zap,
      title: "Lightning Fast Rendering",
      desc: "Zero layout shift with an optimized pipeline. Instant previews as you build.",
      color: "#3858e9",
    },
    {
      icon: Code,
      title: "Developer-First Output",
      desc: "Semantic HTML, clean CSS, full TypeScript support. No bloated markup.",
      color: "#3858e9",
    },
    {
      icon: Globe,
      title: "Responsive by Default",
      desc: "Every block adapts perfectly across desktop, tablet, and mobile viewports.",
      color: "#3858e9",
    },
  ];
  return (
    <div className="bg-white py-24 px-16 border-t border-gray-100">
      <div className="text-center mb-16">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gray-100 mb-5">
          <span className="text-[11px] text-gray-500 font-semibold uppercase tracking-wide">
            Core Features
          </span>
        </div>
        <h2 className="text-[36px] font-bold text-gray-950 tracking-[-0.02em] mb-4">
          Everything professional teams need
        </h2>
        <p className="text-[16px] text-gray-500 max-w-md mx-auto">
          Built for speed, designed for precision, engineered
          for scale.
        </p>
      </div>
      <div className="grid grid-cols-3 gap-6 max-w-5xl mx-auto">
        {features.map((f) => (
          <div
            key={f.title}
            className="group p-8 rounded-3xl border border-gray-100 bg-white hover:border-[#3858e9]/20 hover:shadow-[0_8px_40px_rgba(56,88,233,0.08)] transition-all duration-300"
          >
            <div className="size-12 rounded-2xl bg-[#3858e9]/8 flex items-center justify-center mb-5">
              <f.icon size={20} className="text-[#3858e9]" />
            </div>
            <h3 className="text-[15px] font-semibold text-gray-900 mb-2.5 leading-snug">
              {f.title}
            </h3>
            <p className="text-[13px] text-gray-500 leading-relaxed">
              {f.desc}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

function TestimonialsBlock() {
  const testimonials = [
    {
      name: "Sarah Chen",
      role: "Lead Dev @ Figma",
      avatar: "SC",
      text: "Atomic Editor completely transformed our WordPress workflow. Build times dropped 60%. The output code is actually readable.",
      accent: "#3858e9",
    },
    {
      name: "Marcus Webb",
      role: "Director @ Ember Agency",
      avatar: "MW",
      text: "Finally a WordPress editor that doesn't fight you. The inspector controls are pixel-perfect, and the block system is intuitive.",
      accent: "#5b78ff",
    },
    {
      name: "Priya Sharma",
      role: "CTO @ Launchpad",
      avatar: "PS",
      text: "We switched 12 client sites to Atomic. Performance scores went from 60s to 95s across the board. Clients are thrilled.",
      accent: "#8fa4ff",
    },
  ];
  return (
    <div className="bg-[#fafafa] py-24 px-16 border-t border-gray-100">
      <div className="text-center mb-14">
        <h2 className="text-[36px] font-bold text-gray-950 tracking-[-0.02em] mb-3">
          Trusted by developers
        </h2>
        <p className="text-[16px] text-gray-500">
          Used by 14,000+ teams worldwide.
        </p>
      </div>
      <div className="grid grid-cols-3 gap-5 max-w-5xl mx-auto">
        {testimonials.map((t) => (
          <div
            key={t.name}
            className="p-7 rounded-3xl bg-white border border-gray-100 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex gap-0.5 mb-4">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  size={12}
                  fill="#3858e9"
                  className="text-[#3858e9]"
                />
              ))}
            </div>
            <p className="text-[13px] text-gray-600 leading-relaxed mb-5">
              "{t.text}"
            </p>
            <div className="flex items-center gap-3">
              <div
                className="size-9 rounded-xl flex items-center justify-center text-[11px] font-bold text-white flex-shrink-0"
                style={{ background: t.accent }}
              >
                {t.avatar}
              </div>
              <div>
                <div className="text-[12px] font-semibold text-gray-900">
                  {t.name}
                </div>
                <div className="text-[11px] text-gray-400">
                  {t.role}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function CTABlock() {
  return (
    <div
      className="py-24 px-16 flex flex-col items-center text-center relative overflow-hidden"
      style={{ background: "#0d0f1a" }}
    >
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "radial-gradient(ellipse 60% 60% at 50% 100%, rgba(56,88,233,0.2), transparent)",
        }}
      />
      <div className="relative z-10 flex flex-col items-center">
        <div className="size-14 rounded-2xl bg-[#3858e9]/15 flex items-center justify-center mb-6 border border-[#3858e9]/20">
          <Zap
            size={22}
            className="text-[#3858e9]"
            fill="#3858e9"
          />
        </div>
        <h2 className="text-[40px] font-bold text-white tracking-[-0.02em] mb-4 leading-tight">
          Ready to build something great?
        </h2>
        <p className="text-[16px] text-white/50 max-w-md mb-10 leading-relaxed">
          Join thousands of developers and agencies already
          shipping faster with Atomic Editor.
        </p>
        <div className="flex items-center gap-3">
          <button className="px-8 py-3.5 bg-[#3858e9] text-white text-[14px] font-semibold rounded-2xl hover:bg-[#2a46d1] transition-all shadow-[0_4px_32px_rgba(56,88,233,0.45)]">
            Start Building Free
          </button>
          <button className="px-8 py-3.5 text-white/60 text-[14px] font-medium rounded-2xl border border-white/10 hover:border-white/20 hover:text-white/90 transition-all">
            View Pricing
          </button>
        </div>
      </div>
    </div>
  );
}

const BLOCK_RENDERERS: Record<string, React.FC> = {
  hero: HeroBlock,
  features: FeaturesBlock,
  testimonials: TestimonialsBlock,
  cta: CTABlock,
};

// ─── ACCORDION ────────────────────────────────────────────────────────────────

const INSPECTOR_SECTIONS = [
  { id: "layout", label: "Layout", Content: LayoutControls },
  { id: "spacing", label: "Spacing", Content: SpacingControls },
  {
    id: "background",
    label: "Background",
    Content: BackgroundControls,
  },
  {
    id: "typography",
    label: "Typography",
    Content: TypographyControls,
  },
  { id: "effects", label: "Effects", Content: EffectsControls },
  { id: "border", label: "Border", Content: BorderControls },
];

function AccordionSection({
  id,
  label,
  Content,
  expanded,
  onToggle,
}: {
  id: string;
  label: string;
  Content: React.FC;
  expanded: boolean;
  onToggle: () => void;
}) {
  return (
    <div className="border-b border-white/[0.04]">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/[0.02] transition-colors group"
      >
        <span className="text-[12px] font-medium text-white/60 group-hover:text-white/80 transition-colors">
          {label}
        </span>
        <motion.div
          animate={{ rotate: expanded ? 180 : 0 }}
          transition={{ duration: 0.15 }}
        >
          <ChevronDown size={12} className="text-white/25" />
        </motion.div>
      </button>
      <AnimatePresence initial={false}>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.18, ease: "easeOut" }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4">
              <Content />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── FLOATING TOOLBAR ─────────────────────────────────────────────────────────

function FloatingToolbar({
  onDelete,
}: {
  onDelete: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 6, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 4, scale: 0.96 }}
      transition={{ duration: 0.15, ease: "easeOut" }}
      className="absolute top-3 right-3 z-20 flex items-center gap-0.5 p-1 rounded-2xl shadow-2xl"
      style={{
        background: "rgba(13,13,20,0.92)",
        border: "1px solid rgba(255,255,255,0.08)",
        backdropFilter: "blur(16px)",
      }}
      onClick={(e) => e.stopPropagation()}
    >
      {[
        {
          Icon: GripVertical,
          label: "Drag",
          cursor: "cursor-grab",
        },
        { Icon: Copy, label: "Duplicate", cursor: "" },
        { Icon: Settings, label: "Settings", cursor: "" },
        { Icon: Eye, label: "Visibility", cursor: "" },
      ].map(({ Icon, label, cursor }) => (
        <button
          key={label}
          title={label}
          className={`p-1.5 rounded-xl text-white/35 hover:text-white/90 hover:bg-white/[0.06] transition-colors ${cursor}`}
        >
          <Icon size={13} />
        </button>
      ))}
      <div className="w-px h-4 bg-white/[0.08] mx-0.5" />
      <button
        title="Delete"
        onClick={onDelete}
        className="p-1.5 rounded-xl text-white/25 hover:text-red-400 hover:bg-red-500/10 transition-colors"
      >
        <Trash2 size={13} />
      </button>
    </motion.div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────

export default function App() {
  const [selectedBlock, setSelectedBlock] = useState<
    string | null
  >("hero");
  const [leftOpen, setLeftOpen] = useState(true);
  const [rightOpen, setRightOpen] = useState(true);
  const [leftTab, setLeftTab] = useState<"blocks" | "layers">(
    "blocks",
  );
  const [rightTab, setRightTab] = useState<
    "style" | "advanced" | "responsive"
  >("style");
  const [device, setDevice] = useState<
    "desktop" | "tablet" | "mobile"
  >("desktop");
  const [cmdOpen, setCmdOpen] = useState(false);
  const [cmdQuery, setCmdQuery] = useState("");
  const [expanded, setExpanded] = useState<string[]>([
    "layout",
    "spacing",
  ]);
  const [activeCat, setActiveCat] = useState("layout");
  const [blockSearch, setBlockSearch] = useState("");
  const [saved, setSaved] = useState(false);
  const cmdRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setCmdOpen((p) => !p);
      }
      if (e.key === "Escape") {
        setCmdOpen(false);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  useEffect(() => {
    if (cmdOpen) setTimeout(() => cmdRef.current?.focus(), 50);
    else setCmdQuery("");
  }, [cmdOpen]);

  const toggleExpanded = (id: string) =>
    setExpanded((p) =>
      p.includes(id) ? p.filter((i) => i !== id) : [...p, id],
    );

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const canvasMaxW =
    device === "tablet"
      ? "768px"
      : device === "mobile"
        ? "390px"
        : "100%";

  const selectedData = CANVAS_BLOCKS.find(
    (b) => b.id === selectedBlock,
  );

  const filteredCmds = COMMAND_ITEMS.filter((c) =>
    c.label.toLowerCase().includes(cmdQuery.toLowerCase()),
  );

  const currentCat = BLOCK_CATEGORIES.find(
    (c) => c.id === activeCat,
  );
  const filteredBlocks = blockSearch
    ? BLOCK_CATEGORIES.flatMap((c) =>
        c.blocks.filter((b) =>
          b.label
            .toLowerCase()
            .includes(blockSearch.toLowerCase()),
        ),
      )
    : (currentCat?.blocks ?? []);

  return (
    <div
      className="h-screen w-screen flex flex-col bg-[#0d0d10] overflow-hidden"
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      {/* ── Command Palette ── */}
      <AnimatePresence>
        {cmdOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.12 }}
            className="fixed inset-0 z-[100] flex items-start justify-center pt-[18vh]"
            style={{
              background: "rgba(0,0,0,0.65)",
              backdropFilter: "blur(4px)",
            }}
            onClick={() => setCmdOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, y: -14, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.97 }}
              transition={{ duration: 0.18, ease: "easeOut" }}
              className="w-[560px] rounded-2xl overflow-hidden shadow-[0_32px_80px_rgba(0,0,0,0.6)]"
              style={{
                background: "#12121a",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center gap-3 px-5 py-4 border-b border-white/[0.05]">
                <Command
                  size={14}
                  className="text-white/25 flex-shrink-0"
                />
                <input
                  ref={cmdRef}
                  value={cmdQuery}
                  onChange={(e) => setCmdQuery(e.target.value)}
                  placeholder="Search commands…"
                  className="flex-1 bg-transparent text-[14px] text-white/90 placeholder:text-white/25 outline-none"
                />
                <kbd className="px-1.5 py-0.5 text-[10px] text-white/25 border border-white/10 rounded-md font-mono">
                  ESC
                </kbd>
              </div>
              <div className="py-1.5 max-h-[360px] overflow-y-auto scrollbar-hide">
                {filteredCmds.length === 0 ? (
                  <div className="px-5 py-10 text-center text-[13px] text-white/25">
                    No commands found
                  </div>
                ) : (
                  filteredCmds.map((cmd) => (
                    <button
                      key={cmd.id}
                      className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-white/[0.04] transition-colors group"
                      onClick={() => setCmdOpen(false)}
                    >
                      <div className="size-7 rounded-xl bg-[#1a1a24] group-hover:bg-[#202030] flex items-center justify-center flex-shrink-0 transition-colors">
                        <cmd.icon
                          size={13}
                          className="text-white/45"
                        />
                      </div>
                      <span className="flex-1 text-[13px] text-white/75 text-left group-hover:text-white/90 transition-colors">
                        {cmd.label}
                      </span>
                      <kbd className="text-[10px] text-white/20 font-mono">
                        {cmd.shortcut}
                      </kbd>
                    </button>
                  ))
                )}
              </div>
              <div className="px-5 py-2.5 border-t border-white/[0.04] flex items-center gap-4">
                <div className="flex items-center gap-1.5 text-[10px] text-white/20">
                  <kbd className="px-1.5 py-0.5 border border-white/10 rounded text-[9px] font-mono">
                    ↑↓
                  </kbd>
                  <span>navigate</span>
                </div>
                <div className="flex items-center gap-1.5 text-[10px] text-white/20">
                  <kbd className="px-1.5 py-0.5 border border-white/10 rounded text-[9px] font-mono">
                    ↵
                  </kbd>
                  <span>run</span>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Top Bar ── */}
      <header className="h-14 flex-shrink-0 flex items-center px-4 gap-3 border-b border-white/[0.05] bg-[#0d0d10] z-10">
        {/* Logo */}
        <div className="flex items-center gap-2.5 flex-shrink-0">
          <div className="size-7 rounded-xl bg-[#3858e9] flex items-center justify-center shadow-[0_0_16px_rgba(56,88,233,0.4)]">
            <Zap
              size={13}
              className="text-white"
              fill="white"
            />
          </div>
          <span className="text-[13px] font-semibold text-white tracking-tight">
            Atomic
          </span>
        </div>

        <div className="w-px h-4 bg-white/[0.07] flex-shrink-0" />

        {/* Panel toggles */}
        <div className="flex items-center gap-0.5">
          <button
            onClick={() => setLeftOpen((p) => !p)}
            className={`p-1.5 rounded-lg transition-all ${leftOpen ? "text-white/40 hover:text-white/70 hover:bg-white/[0.05]" : "text-[#3858e9] bg-[#3858e9]/10"}`}
          >
            <PanelLeft size={14} />
          </button>
          <button
            onClick={() => setRightOpen((p) => !p)}
            className={`p-1.5 rounded-lg transition-all ${rightOpen ? "text-white/40 hover:text-white/70 hover:bg-white/[0.05]" : "text-[#3858e9] bg-[#3858e9]/10"}`}
          >
            <PanelRight size={14} />
          </button>
        </div>

        {/* Breadcrumb */}
        <div className="flex items-center gap-1.5 text-[12px] min-w-0">
          <span className="text-white/25 truncate">
            Homepage
          </span>
          <ChevronRight
            size={10}
            className="text-white/15 flex-shrink-0"
          />
          <span className="text-white/50 truncate">
            {selectedData ? selectedData.label : "Canvas"}
          </span>
        </div>

        <div className="flex-1" />

        {/* Device toggle */}
        <div className="flex items-center gap-0.5 p-1 rounded-xl bg-[#12121a] border border-white/[0.05]">
          {(
            [
              ["desktop", Monitor],
              ["tablet", Tablet],
              ["mobile", Smartphone],
            ] as const
          ).map(([d, Icon]) => (
            <button
              key={d}
              onClick={() => setDevice(d)}
              className={`p-1.5 rounded-lg transition-all ${device === d ? "bg-[#202030] text-white shadow-sm" : "text-white/25 hover:text-white/60"}`}
            >
              <Icon size={13} />
            </button>
          ))}
        </div>

        <div className="w-px h-4 bg-white/[0.07] flex-shrink-0" />

        {/* Undo/Redo */}
        <div className="flex items-center gap-0.5">
          <button className="p-1.5 rounded-lg text-white/25 hover:text-white/70 hover:bg-white/[0.05] transition-colors">
            <Undo2 size={14} />
          </button>
          <button className="p-1.5 rounded-lg text-white/25 hover:text-white/70 hover:bg-white/[0.05] transition-colors">
            <Redo2 size={14} />
          </button>
        </div>

        {/* Command button */}
        <button
          onClick={() => setCmdOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#12121a] border border-white/[0.05] text-white/25 hover:text-white/60 hover:border-white/10 transition-all"
        >
          <Command size={11} />
          <span className="text-[11px] font-mono">K</span>
        </button>

        {/* Save */}
        <motion.button
          onClick={handleSave}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.97 }}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[13px] font-semibold transition-all ${saved ? "bg-emerald-500 text-white shadow-[0_0_20px_rgba(16,185,129,0.3)]" : "bg-[#3858e9] text-white shadow-[0_0_20px_rgba(56,88,233,0.3)] hover:bg-[#2a46d1] hover:shadow-[0_0_30px_rgba(56,88,233,0.45)]"}`}
        >
          {saved ? (
            <>
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 400 }}
              >
                ✓
              </motion.div>{" "}
              Saved
            </>
          ) : (
            <>
              <Save size={13} />
              Save
            </>
          )}
        </motion.button>
      </header>

      {/* ── Editor Body ── */}
      <div className="flex flex-1 overflow-hidden">
        {/* ── Left Sidebar ── */}
        <AnimatePresence initial={false}>
          {leftOpen && (
            <motion.aside
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 280, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="h-full flex-shrink-0 flex flex-col bg-[#0d0d10] border-r border-white/[0.05] overflow-hidden"
              style={{ minWidth: 0 }}
            >
              {/* Sidebar tabs */}
              <div className="flex-shrink-0 flex items-center gap-1 px-3 pt-3 pb-2">
                {(["blocks", "layers"] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setLeftTab(tab)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[12px] font-medium transition-all capitalize ${leftTab === tab ? "bg-[#1a1a24] text-white" : "text-white/30 hover:text-white/60"}`}
                  >
                    {tab === "blocks" ? (
                      <Grid3x3 size={11} />
                    ) : (
                      <Layers size={11} />
                    )}
                    {tab.charAt(0).toUpperCase() + tab.slice(1)}
                  </button>
                ))}
              </div>

              <div className="flex-1 overflow-y-auto scrollbar-hide">
                {leftTab === "blocks" ? (
                  <div className="px-3 pb-4">
                    {/* Search */}
                    <div className="relative mb-3">
                      <Search
                        size={12}
                        className="absolute left-3 top-1/2 -translate-y-1/2 text-white/20 pointer-events-none"
                      />
                      <input
                        value={blockSearch}
                        onChange={(e) =>
                          setBlockSearch(e.target.value)
                        }
                        placeholder="Search blocks…"
                        className="w-full pl-8 pr-3 py-2 bg-[#12121a] rounded-xl border border-white/[0.05] text-[12px] text-white/80 placeholder:text-white/20 outline-none focus:border-[#3858e9]/40 transition-colors"
                      />
                    </div>

                    {/* Category tabs */}
                    {!blockSearch && (
                      <div className="flex gap-0.5 mb-3 overflow-x-auto scrollbar-hide pb-0.5">
                        {BLOCK_CATEGORIES.map((cat) => (
                          <button
                            key={cat.id}
                            onClick={() => setActiveCat(cat.id)}
                            className={`flex-shrink-0 px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all ${activeCat === cat.id ? "bg-[#3858e9]/15 text-[#3858e9]" : "text-white/25 hover:text-white/60"}`}
                          >
                            {cat.name}
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Block grid */}
                    <div className="grid grid-cols-2 gap-2">
                      {filteredBlocks.map((block) => (
                        <motion.button
                          key={block.id}
                          whileHover={{ scale: 1.02, y: -1 }}
                          whileTap={{ scale: 0.97 }}
                          className="group flex flex-col items-center gap-2 py-5 px-3 rounded-2xl border border-white/[0.05] bg-[#12121a] hover:bg-[#1e1e2e] hover:border-[#3858e9]/30 transition-all cursor-grab active:cursor-grabbing"
                        >
                          <div className="size-8 rounded-xl bg-[#1a1a24] group-hover:bg-[#252540] flex items-center justify-center transition-colors">
                            <block.icon
                              size={14}
                              className="text-white/35 group-hover:text-[#3858e9] transition-colors"
                            />
                          </div>
                          <span className="text-[10px] font-medium text-white/35 group-hover:text-white/70 transition-colors leading-none">
                            {block.label}
                          </span>
                        </motion.button>
                      ))}
                    </div>

                    {blockSearch &&
                      filteredBlocks.length === 0 && (
                        <div className="text-center py-8 text-[12px] text-white/20">
                          No blocks found
                        </div>
                      )}
                  </div>
                ) : (
                  /* Layers panel */
                  <div className="px-3 pb-4">
                    <div className="text-[10px] font-bold text-white/15 uppercase tracking-[0.1em] mb-3 px-1">
                      Page Structure
                    </div>
                    {CANVAS_BLOCKS.map((block, idx) => {
                      const isActive =
                        selectedBlock === block.id;
                      return (
                        <motion.button
                          key={block.id}
                          onClick={() =>
                            setSelectedBlock(block.id)
                          }
                          whileHover={{ x: 2 }}
                          className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl mb-1 transition-all text-left ${isActive ? "bg-[#3858e9]/10 border border-[#3858e9]/20" : "hover:bg-[#12121a] border border-transparent"}`}
                        >
                          <div
                            className={`size-5 rounded-lg flex items-center justify-center flex-shrink-0 ${isActive ? "bg-[#3858e9]/20" : "bg-[#1a1a24]"}`}
                          >
                            <Layout
                              size={9}
                              className={
                                isActive
                                  ? "text-[#3858e9]"
                                  : "text-white/25"
                              }
                            />
                          </div>
                          <span
                            className={`text-[12px] flex-1 ${isActive ? "text-white font-medium" : "text-white/45"}`}
                          >
                            {block.label}
                          </span>
                          <span className="text-[10px] text-white/15 font-mono">
                            {idx + 1}
                          </span>
                        </motion.button>
                      );
                    })}
                    <button className="w-full flex items-center justify-center gap-1.5 py-2.5 mt-2 rounded-xl border border-dashed border-white/[0.08] text-white/20 hover:text-white/45 hover:border-white/15 transition-colors text-[11px]">
                      <Plus size={10} />
                      Add Section
                    </button>
                  </div>
                )}
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* ── Canvas ── */}
        <main
          className="flex-1 relative overflow-auto scrollbar-hide"
          onClick={() => setSelectedBlock(null)}
          style={{
            background: "#080810",
            backgroundImage:
              "radial-gradient(circle, rgba(255,255,255,0.025) 1px, transparent 1px)",
            backgroundSize: "20px 20px",
          }}
        >
          {/* Canvas zoom bar */}
          <div
            className="sticky top-0 z-10 flex items-center justify-center py-2 pointer-events-none"
            style={{
              background:
                "linear-gradient(to bottom, rgba(8,8,16,0.9) 0%, transparent 100%)",
            }}
          >
            <div
              className="flex items-center gap-2 px-3 py-1.5 rounded-full pointer-events-auto"
              style={{
                background: "rgba(18,18,26,0.85)",
                border: "1px solid rgba(255,255,255,0.05)",
                backdropFilter: "blur(8px)",
              }}
            >
              <span className="text-[11px] text-white/30 font-mono">
                {device === "desktop"
                  ? "1440"
                  : device === "tablet"
                    ? "768"
                    : "390"}
              </span>
              <div className="w-px h-3 bg-white/10" />
              <span className="text-[11px] text-white/25 font-mono">
                100%
              </span>
            </div>
          </div>

          {/* Page */}
          <div
            className="transition-all duration-300 mx-auto shadow-[0_32px_80px_rgba(0,0,0,0.5)] mb-16"
            style={{ maxWidth: canvasMaxW }}
          >
            <div className="bg-white min-h-screen">
              {CANVAS_BLOCKS.map((block) => {
                const Renderer = BLOCK_RENDERERS[block.type];
                const isSel = selectedBlock === block.id;
                return (
                  <div
                    key={block.id}
                    className="relative group"
                    style={{
                      outline: isSel
                        ? "2px solid #3858e9"
                        : "none",
                      outlineOffset: "0px",
                      zIndex: isSel ? 10 : 1,
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedBlock(block.id);
                    }}
                  >
                    {/* Hover outline */}
                    {!isSel && (
                      <div
                        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10"
                        style={{
                          outline:
                            "1px dashed rgba(56,88,233,0.3)",
                          outlineOffset: "0px",
                        }}
                      />
                    )}

                    {/* Block label badge */}
                    {isSel && (
                      <div className="absolute -top-7 left-0 z-20 flex items-center">
                        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-[#3858e9] rounded-t-xl text-white text-[10px] font-semibold">
                          <Layout size={9} />
                          {block.label}
                        </div>
                      </div>
                    )}

                    {/* Floating toolbar */}
                    <AnimatePresence>
                      {isSel && (
                        <FloatingToolbar
                          onDelete={() =>
                            setSelectedBlock(null)
                          }
                        />
                      )}
                    </AnimatePresence>

                    <Renderer />
                  </div>
                );
              })}

              {/* Add section */}
              <div
                className="flex items-center justify-center py-10 bg-gray-50 border-t border-gray-100"
                onClick={(e) => e.stopPropagation()}
              >
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.97 }}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-2xl border border-dashed border-gray-300 text-gray-400 hover:text-[#3858e9] hover:border-[#3858e9]/40 hover:bg-[#3858e9]/5 transition-all text-[13px] font-medium"
                >
                  <Plus size={14} />
                  Add Section
                </motion.button>
              </div>
            </div>
          </div>
        </main>

        {/* ── Right Sidebar (Inspector) ── */}
        <AnimatePresence initial={false}>
          {rightOpen && (
            <motion.aside
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 320, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="h-full flex-shrink-0 flex flex-col bg-[#0d0d10] border-l border-white/[0.05] overflow-hidden"
              style={{ minWidth: 0 }}
            >
              {selectedBlock ? (
                <>
                  {/* Block info header */}
                  <div className="flex-shrink-0 px-4 pt-4 pb-3.5 border-b border-white/[0.05]">
                    <div className="flex items-center gap-2.5 mb-1">
                      <div className="size-7 rounded-xl bg-[#3858e9]/15 border border-[#3858e9]/20 flex items-center justify-center flex-shrink-0">
                        <Layout
                          size={11}
                          className="text-[#3858e9]"
                        />
                      </div>
                      <div>
                        <div className="text-[13px] font-semibold text-white leading-none mb-0.5">
                          {selectedData?.label}
                        </div>
                        <div className="text-[10px] text-white/25 font-mono">
                          block · #{selectedBlock}
                        </div>
                      </div>
                      <div className="ml-auto">
                        <button className="p-1.5 rounded-xl text-white/25 hover:text-white/60 hover:bg-white/[0.05] transition-colors">
                          <Eye size={13} />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Inspector tabs */}
                  <div className="flex-shrink-0 flex items-center gap-1 p-2 border-b border-white/[0.04]">
                    {(
                      [
                        "style",
                        "advanced",
                        "responsive",
                      ] as const
                    ).map((tab) => (
                      <button
                        key={tab}
                        onClick={() => setRightTab(tab)}
                        className={`flex-1 py-1.5 rounded-xl text-[11px] font-medium transition-all capitalize ${rightTab === tab ? "bg-[#1a1a24] text-white shadow-sm" : "text-white/30 hover:text-white/60"}`}
                      >
                        {tab}
                      </button>
                    ))}
                  </div>

                  {/* Inspector content */}
                  <div className="flex-1 overflow-y-auto scrollbar-hide">
                    {rightTab === "style" && (
                      <div className="pb-4">
                        {INSPECTOR_SECTIONS.map(
                          ({ id, label, Content }) => (
                            <AccordionSection
                              key={id}
                              id={id}
                              label={label}
                              Content={Content}
                              expanded={expanded.includes(id)}
                              onToggle={() =>
                                toggleExpanded(id)
                              }
                            />
                          ),
                        )}
                      </div>
                    )}

                    {rightTab === "advanced" && (
                      <div className="p-4 space-y-4">
                        <CGroup label="CSS Classes">
                          <CInput
                            defaultValue=""
                            className="placeholder:text-white/20"
                          />
                        </CGroup>
                        <CGroup label="Element ID">
                          <CInput
                            defaultValue=""
                            className="placeholder:text-white/20"
                          />
                        </CGroup>
                        <CGroup label="Custom CSS">
                          <textarea
                            rows={5}
                            placeholder={
                              "/* Custom styles */\n.selector {\n  color: red;\n}"
                            }
                            className="w-full px-3 py-2.5 bg-[#12121a] rounded-xl border border-white/5 text-[11px] text-white/70 placeholder:text-white/20 outline-none focus:border-[#3858e9]/50 transition-colors font-mono resize-none leading-relaxed"
                          />
                        </CGroup>
                        <CGroup label="Render Conditions">
                          <button className="w-full flex items-center justify-center gap-1.5 py-2 rounded-xl border border-dashed border-white/10 text-[11px] text-white/25 hover:border-white/20 hover:text-white/50 transition-colors">
                            <Plus size={11} />
                            Add Condition
                          </button>
                        </CGroup>
                        <CGroup label="Motion Effect">
                          <select className="w-full px-3 py-1.5 bg-[#12121a] rounded-xl border border-white/5 text-[12px] text-white/70 outline-none appearance-none">
                            <option>None</option>
                            <option>Fade In</option>
                            <option>Slide Up</option>
                            <option>Zoom In</option>
                          </select>
                        </CGroup>
                      </div>
                    )}

                    {rightTab === "responsive" && (
                      <div className="p-4 space-y-4">
                        <CGroup label="Preview Device">
                          <div className="flex items-center gap-0.5 p-1 rounded-xl bg-[#12121a] border border-white/[0.05]">
                            {(
                              [
                                ["desktop", Monitor],
                                ["tablet", Tablet],
                                ["mobile", Smartphone],
                              ] as const
                            ).map(([d, Icon]) => (
                              <button
                                key={d}
                                onClick={() => setDevice(d)}
                                className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-[11px] transition-all capitalize ${device === d ? "bg-[#202030] text-white shadow-sm" : "text-white/30 hover:text-white/60"}`}
                              >
                                <Icon size={12} />
                                {d}
                              </button>
                            ))}
                          </div>
                        </CGroup>
                        <CGroup label="Breakpoint Visibility">
                          <div className="space-y-2">
                            {[
                              ["Desktop", Monitor, true],
                              ["Tablet", Tablet, true],
                              ["Mobile", Smartphone, true],
                            ].map(([label, Icon, val]: any) => (
                              <div
                                key={label}
                                className="flex items-center justify-between px-3 py-2 rounded-xl bg-[#12121a] border border-white/5"
                              >
                                <div className="flex items-center gap-2">
                                  <Icon
                                    size={12}
                                    className="text-white/40"
                                  />
                                  <span className="text-[12px] text-white/60">
                                    {label}
                                  </span>
                                </div>
                                <div
                                  className={`w-8 h-4 rounded-full relative cursor-pointer transition-colors ${val ? "bg-[#3858e9]" : "bg-white/10"}`}
                                >
                                  <div
                                    className={`absolute top-0.5 size-3 bg-white rounded-full shadow transition-all ${val ? "left-4.5" : "left-0.5"}`}
                                    style={{
                                      left: val
                                        ? "18px"
                                        : "2px",
                                    }}
                                  />
                                </div>
                              </div>
                            ))}
                          </div>
                        </CGroup>
                        <CGroup label="Breakpoint Overrides">
                          <button className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl border border-dashed border-white/10 text-[11px] text-white/25 hover:border-[#3858e9]/30 hover:text-[#3858e9]/60 transition-colors">
                            <Plus size={11} />
                            Add Override
                          </button>
                        </CGroup>
                      </div>
                    )}
                  </div>
                </>
              ) : (
                /* Empty state */
                <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
                  <div className="size-14 rounded-2xl bg-[#12121a] border border-white/[0.05] flex items-center justify-center mb-4">
                    <MousePointer
                      size={22}
                      className="text-white/15"
                    />
                  </div>
                  <div className="text-[13px] font-semibold text-white/30 mb-2">
                    No block selected
                  </div>
                  <div className="text-[11px] text-white/15 leading-relaxed max-w-[200px]">
                    Click any block on the canvas to inspect and
                    edit its properties.
                  </div>
                  <div className="mt-6 space-y-1.5 w-full">
                    {[
                      "Layout",
                      "Spacing",
                      "Background",
                      "Typography",
                    ].map((s) => (
                      <div
                        key={s}
                        className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#0f0f18] border border-white/[0.03]"
                      >
                        <div className="size-1.5 rounded-full bg-white/10" />
                        <span className="text-[11px] text-white/15">
                          {s}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.aside>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}